# PitBuzz roadmap

- Future: multi-series support so one rider/team account can switch active race organizations while series/admin access remains organization-specific.
- Team Beta: add secure member invitation/account-linking flow so family/crew can receive in-app and push notifications.
- Team Beta: continue page-structure cleanup across rider and admin screens; keep high-frequency race-day actions separate from configuration.
- Announcements: address scheduled-announcement push delivery when a scheduled item becomes due.
