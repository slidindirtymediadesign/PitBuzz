import { Link } from "react-router-dom";
import { Flag } from "lucide-react";
import { PasswordLoginForm } from "../components/PasswordLoginForm";
import styles from "./login.module.css";

export default function LoginPage() {
  return <main className={styles.page}>
    <section className={styles.panel}>
      <header>
        <div className={styles.logo}><i>★</i><strong>NATVA</strong><i>★</i></div>
        <h1>PITBUZZ</h1>
        <p>NATVA RACE COMMUNICATION</p>
      </header>
      <div className={styles.body}>
        <span className={styles.flag}><Flag/> RACE DAY ACCESS</span>
        <h2>Welcome Back</h2>
        <p>Sign in for NATVA announcements, schedules, private messages and your Team.</p>
        <PasswordLoginForm/>
        <div className={styles.forgot}><Link to="/forgot-password">Forgot password?</Link></div>
        <div className={styles.register}>New rider? <Link to="/register">Create an account</Link></div>
      </div>
      <footer><Link to="/privacy">Privacy Policy</Link><span>•</span><Link to="/terms">Terms of Use</Link><img className={styles.footerLogo} src="/_cdn/static/444c2ed7-0e9e-4912-80b5-f5e4b076f45b-pitbuzz-official-logo-transparent.png" alt="PitBuzz — Race-Day Communication"/></footer>
    </section>
  </main>;
}