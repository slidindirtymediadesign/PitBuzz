import { useEffect, useMemo, useState } from "react";
import { ArrowLeft, KeyRound, Search, ShieldCheck, X } from "lucide-react";
import { toast } from "sonner";
import { Link } from "react-router-dom";
import { Input } from "../components/Input";
import { Button } from "../components/Button";
import { AdminUser, getAdminUsers } from "../endpoints/admin-users_GET.schema";
import { adminResetPassword } from "../endpoints/admin-password-reset_POST.schema";
import styles from "./users.module.css";

export default function UsersPage(){
  const [users,setUsers]=useState<AdminUser[]>([]);
  const [query,setQuery]=useState("");
  const [resetting,setResetting]=useState<number|null>(null);
  const [saving,setSaving]=useState<number|null>(null);
  const [passwords,setPasswords]=useState<Record<number,string>>({});
  const load=()=>getAdminUsers().then(d=>setUsers(d.users)).catch(e=>toast.error(e.message));
  useEffect(()=>{void load()},[]);
  const visible=useMemo(()=>{const q=query.trim().toLowerCase();return q?users.filter(user=>`${user.displayName} ${user.email} ${user.role}`.toLowerCase().includes(q)):users},[users,query]);
  const reset=async(user:AdminUser)=>{if(saving!==null)return;setSaving(user.id);try{await adminResetPassword({userId:user.id,newPassword:passwords[user.id]||"",requestId:user.resetRequestId});setPasswords(v=>({...v,[user.id]:""}));setResetting(null);toast.success(`Password reset for ${user.displayName}`);await load()}catch(e){toast.error(e instanceof Error?e.message:"Could not reset password")}finally{setSaving(null)}};
  return <main className={styles.page}>
    <header><Link to="/" aria-label="Back to PitBuzz"><ArrowLeft/></Link><div><strong>USERS & STAFF</strong><span>ACCOUNT ACCESS</span></div></header>
    <section className={styles.content}>
      <div className={styles.security}><ShieldCheck/><span>Only administrators can reset passwords. Existing passwords are never displayed.</span></div>
      <label className={styles.search}><Search/><Input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search name, email, or role"/>{query&&<button onClick={()=>setQuery("")} aria-label="Clear search"><X/></button>}</label>
      <div className={styles.summary}><strong>{visible.length}</strong><span>{visible.length===1?"ACCOUNT":"ACCOUNTS"}</span></div>
      {!visible.length&&<div className={styles.empty}>No accounts match that search.</div>}
      {visible.map(user=><article key={user.id}>
        <div className={styles.identity}><div><h2>{user.displayName}</h2><p>{user.email}</p></div><b>{user.role.replace("_"," ").toUpperCase()}</b></div>
        {user.resetRequestId&&<div className={styles.request}><KeyRound/> PASSWORD RESET REQUESTED</div>}
        {resetting===user.id?<div className={styles.reset}><Input autoFocus type="password" autoComplete="new-password" disabled={saving===user.id} placeholder="New temporary password — 8+ characters" value={passwords[user.id]||""} onChange={e=>setPasswords(v=>({...v,[user.id]:e.target.value}))}/><div className={styles.resetActions}><Button variant="outline" disabled={saving===user.id} onClick={()=>{setResetting(null);setPasswords(v=>({...v,[user.id]:""}))}}>CANCEL</Button><Button disabled={(passwords[user.id]||"").length<8||saving!==null} onClick={()=>void reset(user)}>{saving===user.id?"SAVING…":"SAVE PASSWORD"}</Button></div></div>:<button className={styles.resetOpen} disabled={saving!==null} onClick={()=>setResetting(user.id)}><KeyRound/> RESET PASSWORD</button>}
      </article>)}
    </section>
  </main>
}