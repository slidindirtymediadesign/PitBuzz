import { FormEvent,useEffect,useMemo,useState } from "react";
import { ArrowDown,ArrowLeft,ArrowUp,CalendarDays,Pencil,Plus,Trash2 } from "lucide-react";
import { useAuth } from "../helpers/useAuth";
import { Button } from "../components/Button";
import { Input } from "../components/Input";
import { Select,SelectContent,SelectItem,SelectTrigger,SelectValue } from "../components/Select";
import { getScheduleItems,ScheduleItem } from "../endpoints/schedule-items_GET.schema";
import { postScheduleItem } from "../endpoints/schedule-items_POST.schema";
import styles from "./schedule.module.css";
import { useNavigate } from "react-router-dom";

type RaceClass={id:string;name:string};
const blank={id:null as string|null,title:"",eventDate:new Date().toISOString().slice(0,10),scheduledTime:"",location:"",raceNumber:"",status:"active" as "active"|"hidden",classId:""};

export default function SchedulePage(){
  const navigate=useNavigate();
  const {authState}=useAuth();
  const staff=authState.type==="authenticated"&&["super_admin","admin","announcer"].includes(authState.user.role);
  const [items,setItems]=useState<ScheduleItem[]>([]),[classes,setClasses]=useState<RaceClass[]>([]),[loading,setLoading]=useState(true),[editing,setEditing]=useState(false),[form,setForm]=useState(blank),[notice,setNotice]=useState(""),[saving,setSaving]=useState(false),[mutatingId,setMutatingId]=useState<string|null>(null);
  const load=async()=>{setLoading(true);try{const data=await getScheduleItems(Boolean(staff));setItems(data.items)}finally{setLoading(false)}};
  useEffect(()=>{load();fetch("/_api/classes").then(r=>r.json()).then(d=>setClasses(d.classes??[])).catch(()=>setClasses([]))},[staff]);
  const grouped=useMemo(()=>items.reduce<Record<string,ScheduleItem[]>>((acc,item)=>{const key=item.eventDate.slice(0,10);(acc[key]??=[]).push(item);return acc},{}),[items]);
  const edit=(item:ScheduleItem)=>{setForm({id:item.id,title:item.title,eventDate:item.eventDate.slice(0,10),scheduledTime:item.scheduledTime?.slice(0,5)??"",location:item.location??"",raceNumber:item.raceNumber?String(item.raceNumber):"",status:item.status==="hidden"?"hidden":"active",classId:item.classId??""});setEditing(true);setNotice("")};
  const submit=async(e:FormEvent)=>{e.preventDefault();setSaving(true);setNotice("");try{await postScheduleItem({action:"save",id:form.id,title:form.title,eventDate:form.eventDate,scheduledTime:form.scheduledTime||null,location:form.location||null,raceNumber:form.raceNumber?Number(form.raceNumber):null,status:form.status,classId:form.classId||null});setEditing(false);setForm(blank);setNotice("Schedule saved.");await load()}catch(error){setNotice(error instanceof Error?error.message:"Could not save schedule")}finally{setSaving(false)}};
  const mutate=async(body:Parameters<typeof postScheduleItem>[0])=>{const id="id" in body?body.id:null;if(id)setMutatingId(id);setNotice("");try{await postScheduleItem(body);setNotice(body.action==="delete"?"Schedule item deleted.":"Schedule order updated.");await load()}catch(error){setNotice(error instanceof Error?error.message:"Could not update schedule")}finally{setMutatingId(null)}};
  return <main className={styles.page}><header><button onClick={()=>navigate("/")} aria-label="Back to PitBuzz"><ArrowLeft/></button><div><small>PITBUZZ • NATVA</small><h1>{staff?"Schedule Manager":"Race-Day Schedule"}</h1></div>{staff&&<Button disabled={editing||saving||mutatingId!==null} onClick={()=>{setForm(blank);setEditing(true);setNotice("")}}><Plus/> ADD</Button>}</header>
    <p className={styles.modeNote}>{staff?"Build the race order here. Riders only see active items that match their selected classes or Team riders.":"Your schedule is filtered to your selected race classes and Team riders."}</p>
    {notice&&<p className={styles.notice}>{notice}</p>}
    {editing&&staff&&<form className={styles.editor} onSubmit={submit}>
      <div className={styles.editorHead}><strong>{form.id?"EDIT SCHEDULE ITEM":"ADD SCHEDULE ITEM"}</strong><button type="button" disabled={saving} onClick={()=>setEditing(false)}>CANCEL</button></div>
      <label>Title<Input disabled={saving} value={form.title} onChange={e=>setForm({...form,title:e.target.value})} required/></label>
      <div className={styles.two}><label>Date<Input disabled={saving} type="date" value={form.eventDate} onChange={e=>setForm({...form,eventDate:e.target.value})} required/></label><label>Time<Input disabled={saving} type="time" value={form.scheduledTime} onChange={e=>setForm({...form,scheduledTime:e.target.value})}/></label></div>
      <label>Location / Detail<Input disabled={saving} value={form.location} onChange={e=>setForm({...form,location:e.target.value})}/></label>
      <div className={styles.two}><label>Race #<Input disabled={saving} inputMode="numeric" value={form.raceNumber} onChange={e=>setForm({...form,raceNumber:e.target.value.replace(/\D/g,"")})}/></label><label>Class<Select disabled={saving} value={form.classId||"_all"} onValueChange={value=>setForm({...form,classId:value==="_all"?"":value})}><SelectTrigger><SelectValue/></SelectTrigger><SelectContent><SelectItem value="_all">All / General</SelectItem>{classes.map(c=><SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent></Select></label></div>
      <label>Status<Select disabled={saving} value={form.status} onValueChange={value=>setForm({...form,status:value as "active"|"hidden"})}><SelectTrigger><SelectValue/></SelectTrigger><SelectContent><SelectItem value="active">Active</SelectItem><SelectItem value="hidden">Hidden</SelectItem></SelectContent></Select></label>
      <div className={styles.editorActions}><Button type="button" variant="outline" disabled={saving} onClick={()=>{setEditing(false);setForm(blank)}}>CANCEL</Button><Button type="submit" disabled={saving}>{saving?"SAVING…":"SAVE SCHEDULE ITEM"}</Button></div>
    </form>}
    {loading?<section className={styles.empty}>Loading schedule…</section>:!items.length?<section className={styles.empty}><CalendarDays/><strong>No schedule items yet.</strong><span>{staff?"Tap ADD to build the race-day schedule.":"The race-day schedule will appear here."}</span></section>:
      Object.entries(grouped).map(([date,dayItems])=><section key={date} className={styles.day}><h2>{new Date(`${date}T12:00:00`).toLocaleDateString([], {weekday:"long",month:"long",day:"numeric"})}</h2>{dayItems.map((item,index)=><article key={item.id} className={item.status==="hidden"?styles.hidden:""}><time>{item.scheduledTime?new Date(`2000-01-01T${item.scheduledTime}`).toLocaleTimeString([], {hour:"numeric",minute:"2-digit"}):"TBA"}</time><div><strong>{item.raceNumber?`Race ${item.raceNumber} — `:""}{item.title}</strong><span>{item.location||"Race-day schedule"}{staff&&item.status==="hidden"?" • HIDDEN FROM RIDERS":""}</span></div>{staff&&<div className={styles.actions}><button aria-label={`Move ${item.title} up`} disabled={mutatingId!==null||index===0} onClick={()=>mutate({action:"move",id:item.id,direction:"up"})}><ArrowUp/></button><button aria-label={`Move ${item.title} down`} disabled={mutatingId!==null||index===dayItems.length-1} onClick={()=>mutate({action:"move",id:item.id,direction:"down"})}><ArrowDown/></button><button aria-label={`Edit ${item.title}`} disabled={mutatingId!==null} onClick={()=>edit(item)}><Pencil/></button><button aria-label={`Delete ${item.title}`} disabled={mutatingId!==null} onClick={()=>{if(confirm(`Delete ${item.title}?`))mutate({action:"delete",id:item.id})}}><Trash2/></button></div>}</article>)}</section>)}
  </main>
}