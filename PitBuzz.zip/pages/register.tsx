import { Link } from "react-router-dom";
import { PasswordRegisterForm } from "../components/PasswordRegisterForm";
import styles from "./login.module.css";

export default function RegisterPage() {
  return <main className={styles.page}>
    <section className={styles.panel}>
      <header>
        <div className={styles.logo}><i>★</i><strong>NATVA</strong><i>★</i></div>
        <h1>RIDER REGISTRATION</h1>
        <p>ONE ACCOUNT FOR YOUR RACE-DAY COMMUNICATION</p>
      </header>
      <div className={styles.body}>
        <span className={styles.flag}>NEW PITBUZZ ACCOUNT</span>
        <h2>Create Account</h2>
        <p>Create your PitBuzz login. After registration, choose the NATVA race classes you want to follow.</p>
        <PasswordRegisterForm/>
        <div className={styles.register}>Already registered? <Link to="/login">Sign in</Link></div>
      </div>
      <footer><Link to="/privacy">Privacy Policy</Link><span>•</span><Link to="/terms">Terms of Use</Link><img className={styles.footerLogo} src="/_cdn/static/444c2ed7-0e9e-4912-80b5-f5e4b076f45b-pitbuzz-official-logo-transparent.png" alt="PitBuzz — Race-Day Communication"/></footer>
    </section>
  </main>;
}