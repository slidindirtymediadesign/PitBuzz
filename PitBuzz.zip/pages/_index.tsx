import { useEffect, useState } from "react";
import { BellOff, BellRing, CalendarDays, CheckCircle2, ChevronDown, ChevronRight, Gauge, Headphones, History, Home, MessageSquare, Radio, Send, Settings, UserRound, Users } from "lucide-react";
import { toast } from "sonner";
import { Link, useNavigate } from "react-router-dom";
import { AnnouncementComposer } from "../components/AnnouncementComposer";
import { LiveAnnouncement } from "../components/LiveAnnouncement";
import { PrivateMessageComposer } from "../components/PrivateMessageComposer";
import { RaceDaySchedule } from "../components/RaceDaySchedule";
import { useThemeMode } from "../helpers/themeMode";
import { useAuth } from "../helpers/useAuth";
import { disablePush, enablePush, onPushEnabledChange } from "../helpers/pushClient";
import styles from "./_index.module.css";

const NotificationToggle = () => {
  const navigate = useNavigate();
  const { authState } = useAuth();
  const [enabled, setEnabled] = useState(false);
  const [busy, setBusy] = useState(false);
  useEffect(() => onPushEnabledChange(setEnabled), []);
  const authenticated = authState.type === "authenticated";
  const toggle = async () => {
    if (!authenticated) {
      navigate("/login");
      return;
    }
    setBusy(true);
    try {
      if (enabled) await disablePush();
      else await enablePush();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Notification setting could not be changed");
    } finally {
      setBusy(false);
    }
  };
  return <button type="button" className={styles.notificationToggle} onClick={toggle} disabled={busy} aria-pressed={authenticated?enabled:undefined} aria-label={authenticated ? (enabled ? "Disable PitBuzz notifications" : "Enable PitBuzz notifications") : "Sign in to enable PitBuzz notifications"}>
    {enabled ? <BellRing/> : <BellOff/>}
    <span>{busy ? "WAIT" : authenticated ? (enabled ? "ON" : "ENABLE") : "SIGN IN"}</span>
  </button>;
};

const AdminDashboard = () => {
  const navigate = useNavigate();
  const { mode, switchToDarkMode, switchToLightMode } = useThemeMode();
  const { authState, logout } = useAuth();
  const [composerOpen, setComposerOpen] = useState(false);
  const [privateOpen, setPrivateOpen] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);
  const actions = [
    { icon: <Send/>, title: "NEW ANNOUNCEMENT", detail: "Send to rider devices", red: true, onClick: () => setComposerOpen(true) },
    { icon: <MessageSquare/>, title: "PRIVATE MESSAGE", detail: "Send to one rider", onClick: () => setPrivateOpen(true) },
    { icon: <CalendarDays/>, title: "MANAGE SCHEDULE", detail: "Add / Edit / Reorder", red: true, onClick: () => navigate("/schedule") },
    { icon: <History/>, title: "ANNOUNCEMENT HISTORY", detail: "View past messages", onClick: () => navigate("/announcements") },
    { icon: <Users/>, title: "USERS & STAFF", detail: "Manage access", onClick: () => navigate("/users") },
    { icon: <Settings/>, title: "AUDIO SETTINGS", detail: "Auto-play, voice & audio test", onClick: () => navigate("/audio") },
  ];
  return (
    <main className={styles.app}>
      <header className={styles.header}>
        <span className={styles.headerSpacer}/>
        <div className={styles.logo}>
          <div className={styles.logoTop}><i className={styles.leftStripes}>★</i><span>NATVA</span><i className={styles.rightStripes}>★</i></div>
          <p>PITBUZZ</p><small>★ NATVA ADMIN ★</small>
        </div>
        <NotificationToggle/>
      </header>
      <div className={styles.content}>
        <section className={styles.connected}><CheckCircle2/><div><strong>CONNECTED</strong><span>PitBuzz race-day services are reachable</span></div></section>
        {authState.type==="authenticated"&&<section className={styles.accountStrip}><div><strong>{authState.user.displayName}</strong><span>{authState.user.role.replaceAll("_"," ").toUpperCase()}</span></div><button onClick={()=>logout()}>SIGN OUT</button></section>}
        <div className={styles.sectionHead}><strong>ADMIN QUICK ACTIONS</strong></div>
        <section className={styles.adminGrid}>
          {actions.map((action) => <button key={action.title} onClick={action.onClick} className={action.red ? styles.redAction : ""}><span>{action.icon}</span><strong>{action.title}</strong><small>{action.detail}</small></button>)}
        </section>
        <LiveAnnouncement admin refreshKey={refreshKey}/>
        <div className={styles.sectionHead}><strong>TODAY’S SCHEDULE</strong><button onClick={()=>navigate("/schedule")}>VIEW FULL SCHEDULE <ChevronRight/></button></div>
        <RaceDaySchedule limit={3}/>
        <footer className={styles.softwareCopyright}><img src="/_cdn/static/444c2ed7-0e9e-4912-80b5-f5e4b076f45b-pitbuzz-official-logo-transparent.png" alt="PitBuzz — Race-Day Communication"/></footer>
      </div>
      <nav className={styles.nav}>
        <Link to="/" className={styles.active}><Gauge/><span>Dashboard</span></Link><Link to="/schedule"><CalendarDays/><span>Schedule</span></Link><Link to="/announcements"><MessageSquare/><span>Messages</span></Link><Link to="/users"><UserRound/><span>Users</span></Link><button type="button" onClick={() => mode==="dark"?switchToLightMode():switchToDarkMode()}><Settings/><span>{mode==="dark"?"Light Mode":"Dark Mode"}</span></button>
      </nav>
      {composerOpen&&<AnnouncementComposer onClose={()=>setComposerOpen(false)} onSent={()=>{setRefreshKey(v=>v+1);window.setTimeout(()=>setComposerOpen(false),900)}}/>}
      {privateOpen&&<PrivateMessageComposer onClose={()=>setPrivateOpen(false)} onSent={()=>{setRefreshKey(v=>v+1);window.setTimeout(()=>setPrivateOpen(false),900)}}/>}
    </main>
  );
};

export default function RiderHome() {
  const navigate = useNavigate();
  const { mode, switchToDarkMode, switchToLightMode } = useThemeMode();
  const { authState, logout } = useAuth();
  const [helpOpen, setHelpOpen] = useState(false);

  const signedInStaff=authState.type==="authenticated"&&["super_admin","admin","announcer"].includes(authState.user.role);
  if (signedInStaff) return <AdminDashboard/>;

  return (
    <main className={styles.app}>
      <header className={styles.header}>
        <span className={styles.headerSpacer}/>
        <div className={styles.logo}>
          <div className={styles.logoTop}><i className={styles.leftStripes}>★</i><span>NATVA</span><i className={styles.rightStripes}>★</i></div>
          <p>PITBUZZ</p>
          <small>— NATVA RACE COMMUNICATION —</small>
        </div>
        <NotificationToggle />
      </header>

      <div className={styles.content}>
        <section className={styles.connected}>
          <CheckCircle2 />
          <div><strong>CONNECTED</strong><span>PitBuzz race-day services are reachable</span></div>
        </section>
        {authState.type !== "authenticated" && <section className={styles.authActions}>
          <Link to="/login">SIGN IN</Link>
          <Link to="/register">CREATE ACCOUNT</Link>
        </section>}
        {authState.type === "authenticated" && <section className={styles.accountStrip}><div><strong>Welcome, {authState.user.displayName}</strong><span>Only announcements for your selected classes will appear or play.</span></div><div className={styles.accountButtons}><Link to="/team">MY TEAM</Link><Link to="/choose-classes">RACE CLASSES</Link><button onClick={()=>logout()}>SIGN OUT</button></div></section>}
        <div className={styles.sectionHead}><strong>LATEST ANNOUNCEMENT</strong><button onClick={() => navigate("/announcements")}>VIEW ALL <ChevronRight /></button></div>
        <LiveAnnouncement/>
        <div className={styles.dots}><i/><i/><i/></div>

        <div className={styles.sectionHead}><strong>TODAY’S SCHEDULE</strong><button onClick={()=>navigate("/schedule")}>VIEW FULL SCHEDULE <ChevronRight /></button></div>
        <RaceDaySchedule/>

        <section className={styles.help}>
          <button onClick={() => setHelpOpen(!helpOpen)}><span><Radio/> Race-day troubleshooting</span><ChevronDown className={helpOpen ? styles.rotated : ""}/></button>
          {helpOpen && <ul><li>Confirm the status above says CONNECTED.</li><li>Use the bell at the top right to enable PitBuzz notifications.</li><li>Allow PitBuzz notifications in your phone settings.</li><li>Turn off Focus or Do Not Disturb during racing.</li><li>Turn up media volume, then test audio.</li><li>If needed, close and reopen PitBuzz.</li></ul>}
        </section>
        <footer className={styles.softwareCopyright}><img src="/_cdn/static/444c2ed7-0e9e-4912-80b5-f5e4b076f45b-pitbuzz-official-logo-transparent.png" alt="PitBuzz — Race-Day Communication"/></footer>
      </div>

      <nav className={styles.nav}>
        <Link to="/" className={styles.active}><Home/><span>Home</span></Link><Link to="/schedule"><CalendarDays/><span>Schedule</span></Link><Link to="/audio"><Headphones/><span>Audio</span></Link><Link to="/announcements"><MessageSquare/><span>Messages</span></Link><button type="button" onClick={() => mode === "dark" ? switchToLightMode() : switchToDarkMode()} title="Switch light or dark mode"><Settings/><span>{mode === "dark" ? "Light Mode" : "Dark Mode"}</span></button>
      </nav>
    </main>
  );
}