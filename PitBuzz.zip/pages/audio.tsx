import { useEffect,useState } from "react";
import { ArrowLeft,Volume2,VolumeX } from "lucide-react";
import { Button } from "../components/Button";
import { useNavigate } from "react-router-dom";
import { playPitBuzzAlert,speakPitBuzzAnnouncement } from "../helpers/alertAudio";
import styles from "./audio.module.css";

export default function AudioSettings(){
  const navigate=useNavigate();
  const [autoPlay,setAutoPlay]=useState(()=>typeof localStorage==="undefined"||localStorage.getItem("pitbuzz-autoplay")!=="0");
  const [testing,setTesting]=useState(false);
  const toggle=()=>setAutoPlay(current=>{const next=!current;localStorage.setItem("pitbuzz-autoplay",next?"1":"0");window.dispatchEvent(new Event("pitbuzz:audio-settings"));if(next)speakPitBuzzAnnouncement("Auto-play on");else window.speechSynthesis?.cancel();return next});
  const test=()=>{setTesting(true);playPitBuzzAlert();const started=speakPitBuzzAnnouncement("PitBuzz audio test. Your announcement audio is working.",()=>setTesting(true),()=>setTesting(false));if(!started)setTesting(false)};
  useEffect(()=>()=>window.speechSynthesis?.cancel(),[]);
  return <main className={styles.page}>
    <section className={styles.panel}>
      <header><button onClick={()=>navigate("/")} aria-label="Back to PitBuzz"><ArrowLeft/></button><div><small>PITBUZZ • NATVA</small><h1>Audio Settings</h1><p>Spoken race-day announcement controls</p></div></header>
      <section className={styles.setting}>
        <div>{autoPlay?<Volume2/>:<VolumeX/>}<div><strong>Auto-Play Audio</strong><span>Automatically speak each new unread announcement one time.</span></div></div>
        <button className={autoPlay?styles.on:styles.off} onClick={toggle}>{autoPlay?"ON":"OFF"}</button>
      </section>
      <section className={styles.info}><strong>Announcement Voice</strong><span>PitBuzz automatically uses the best available English female voice on this device.</span></section>
      <Button size="lg" onClick={test} disabled={testing}><Volume2/>{testing?"PLAYING TEST…":"TEST AUDIO"}</Button>
      <p className={styles.note}>Auto-play applies to regular race-day announcements only. Private messages stay silent unless you choose to play them manually.</p>
    </section>
  </main>
}