import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Flag, LoaderCircle } from "lucide-react";
import { Checkbox } from "../components/Checkbox";
import { Button } from "../components/Button";
import { getClasses } from "../endpoints/classes_GET.schema";
import { getSubscriptions } from "../endpoints/subscriptions_GET.schema";
import { postSubscriptions } from "../endpoints/subscriptions_POST.schema";
import styles from "./choose-classes.module.css";

export default function ChooseClasses(){
  const navigate=useNavigate();
  const [chosen,setChosen]=useState<string[]|null>(null);
  const classes=useQuery({queryKey:["classes"],queryFn:getClasses});
  const saved=useQuery({queryKey:["subscriptions"],queryFn:getSubscriptions,retry:false});
  const selected=chosen ?? saved.data?.classIds ?? [];
  const save=useMutation({mutationFn:()=>postSubscriptions({classIds:selected}),onSuccess:()=>navigate("/")});
  const toggle=(id:string)=>setChosen(selected.includes(id)?selected.filter(x=>x!==id):[...selected,id]);
  return <main className={styles.page}><section className={styles.panel}>
    <header><button onClick={()=>navigate("/")} aria-label="Back to PitBuzz"><ArrowLeft/></button><Flag/><div><small>RIDER SETTINGS</small><h1>Race Classes</h1><p>Choose the classes you want PitBuzz announcements and schedules for.</p></div></header>
    {classes.isError?<div className={styles.loading}>Could not load race classes. Check your connection and try again.</div>:classes.isPending?<div className={styles.loading}><LoaderCircle/> Loading classes…</div>:
      <div className={styles.grid}>{classes.data?.classes.map(c=><label key={c.id}><Checkbox checked={selected.includes(c.id)} onChange={()=>toggle(c.id)}/><span>{c.name}</span></label>)}</div>}
    <footer><span>{selected.length?`${selected.length} selected`:"General announcements only"}</span><Button disabled={save.isPending||classes.isPending||classes.isError||saved.isPending} onClick={()=>save.mutate()}>{save.isPending?"Saving…":"SAVE CLASSES"}</Button></footer>
    {save.isError&&<p className={styles.error}>Classes could not be saved. Please try again.</p>}
  </section></main>
}