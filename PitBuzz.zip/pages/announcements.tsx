import { useEffect, useState } from "react";
import { ArrowLeft, Clock3, Mail, MessageSquare, Volume2 } from "lucide-react";
import { Link } from "react-router-dom";
import { AnnouncementItem, getAnnouncements } from "../endpoints/announcements_GET.schema";
import { postAnnouncementRead } from "../endpoints/announcement-read_POST.schema";
import { speakPitBuzzAnnouncement } from "../helpers/alertAudio";
import styles from "./announcements.module.css";

export default function AnnouncementsPage() {
  const [items, setItems] = useState<AnnouncementItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter,setFilter]=useState<"all"|"announcements"|"private">("all");
  const [readingId,setReadingId]=useState<string|null>(null);
  const [playingId,setPlayingId]=useState<string|null>(null);
  const [error,setError]=useState("");
  const markRead = async (id:string) => { if(readingId)return;setReadingId(id);setError("");try{await postAnnouncementRead({announcementId:id});setItems(current=>current.map(item=>item.id===id?{...item,isRead:true}:item))}catch{setError("Could not mark that message as read. Try again.")}finally{setReadingId(null)} };
  useEffect(() => {
    getAnnouncements().then((data) => setItems(data.announcements)).catch(()=>setError("Could not load messages. Check your connection and try again.")).finally(() => setLoading(false));
  }, []);
  const visible=items.filter(item=>filter==="all"||(filter==="private"?item.kind==="private":item.kind!=="private"));
  const unread=items.filter(item=>!item.isRead).length;
  return <main className={styles.page}>
    <header><Link to="/" aria-label="Back to PitBuzz"><ArrowLeft/></Link><div><strong>ANNOUNCEMENTS</strong><span>PITBUZZ MESSAGE HISTORY</span></div></header>
    <section className={styles.content}>
      <p className={styles.note}>Race-day announcements remain here for one hour. Private messages are clearly marked and never auto-play aloud.</p>
      {error&&<p role="alert" style={{margin:"0 0 10px",padding:"9px 10px",border:"1px solid #dc162b",borderRadius:5,color:"#b91c1c",fontSize:13,fontWeight:700}}>{error}</p>}
      <div className={styles.overview}><span><b>{unread}</b> UNREAD</span><span><b>{items.filter(i=>i.kind==="private").length}</b> PRIVATE</span></div>
      <nav className={styles.filters} aria-label="Message filters"><button className={filter==="all"?styles.active:""} onClick={()=>setFilter("all")}>ALL</button><button className={filter==="announcements"?styles.active:""} onClick={()=>setFilter("announcements")}>ANNOUNCEMENTS</button><button className={filter==="private"?styles.active:""} onClick={()=>setFilter("private")}>PRIVATE</button></nav>
      {loading && <div className={styles.empty}>Loading announcements…</div>}
      {!loading && !items.length && <div className={styles.empty}><MessageSquare/><strong>No active announcements</strong><span>New race-day messages will appear here.</span></div>}
      {!loading&&items.length>0&&!visible.length&&<div className={styles.empty}><MessageSquare/><strong>Nothing in this view</strong><span>Try another message filter.</span></div>}
      {visible.map((item) => <article key={item.id} className={`${item.isRead ? styles.read : styles.unread} ${item.kind==="private"?styles.private:""}`}>
        <div className={styles.meta}><b>{item.kind==="private"?"PRIVATE MESSAGE":item.kind.toUpperCase()}</b><time><Clock3/>{item.sentAt ? new Date(item.sentAt).toLocaleTimeString([], {hour:"numeric",minute:"2-digit"}) : "Scheduled"}</time></div>
        <h2>{item.title}</h2><p>{item.message}</p>
        <footer><span className={item.isRead ? styles.readStatus : styles.newStatus}>{item.isRead ? <><i className={styles.readLight}/> READ</> : <><Mail/> NEW</>}</span><div className={styles.actions}>{!item.isRead&&<button disabled={readingId!==null} onClick={()=>void markRead(item.id)}>{readingId===item.id?"MARKING…":"MARK READ"}</button>}<button onClick={() => {window.speechSynthesis?.cancel();setPlayingId(item.id);const started=speakPitBuzzAnnouncement(item.message,undefined,()=>setPlayingId(current=>current===item.id?null:current));if(!started)setPlayingId(null)}}><Volume2/> {playingId===item.id?"PLAYING…":"PLAY AUDIO"}</button></div></footer>
      </article>)}
    </section>
  </main>;
}