import { FormEvent, useEffect, useState } from "react";
import { ArrowLeft, Eye, Send, X } from "lucide-react";
import { Input } from "./Input";
import { Textarea } from "./Textarea";
import { Button } from "./Button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./Select";
import { postAnnouncement } from "../endpoints/announcements_POST.schema";
import styles from "./AnnouncementComposer.module.css";

type RaceClass={id:string;name:string};
type Category="General"|"Schedule Update"|"Race Day"|"Emergency"|"Registration"|"Weather"|"Results / Awards";
const quickAnnouncements = [
  { key:"meeting", label:"RIDERS MEETING", title:"Riders Meeting", message:"Riders meeting will be at 9:00 AM. Please report to the riders meeting area.", category:"Race Day" as Category },
  { key:"registration", label:"REGISTRATION", title:"Registration", message:"Registration is open. Please come to registration and complete your check-in.", category:"Registration" as Category },
  { key:"staging", label:"STAGING CALL", title:"Staging Call", message:"Riders, please report to staging for your upcoming race.", category:"Race Day" as Category },
  { key:"practice", label:"PRACTICE", title:"Practice", message:"Practice will begin shortly. Riders, please be ready and listen for your class call.", category:"Race Day" as Category },
  { key:"weather", label:"WEATHER DELAY", title:"Weather Delay", message:"Racing is temporarily delayed due to weather. Please watch the app for the next update.", category:"Weather" as Category },
  { key:"awards", label:"AWARDS", title:"Awards", message:"Awards will begin shortly. Please report to the awards area.", category:"Results / Awards" as Category },
];
export function AnnouncementComposer({onClose,onSent}:{onClose:()=>void;onSent:()=>void}){
  const [title,setTitle]=useState("");
  const [message,setMessage]=useState("");
  const [category,setCategory]=useState<Category>("General");
  const [allRiders,setAllRiders]=useState(true);
  const [officials,setOfficials]=useState(false);
  const [classes,setClasses]=useState<RaceClass[]>([]);
  const [classIds,setClassIds]=useState<string[]>([]);
  const [sendMode,setSendMode]=useState<"now"|"later">("now");
  const [scheduledFor,setScheduledFor]=useState("");
  const [sending,setSending]=useState(false);
  const [notice,setNotice]=useState("");
  const [previewing,setPreviewing]=useState(false);
  const [classesLoading,setClassesLoading]=useState(true);
  useEffect(()=>{fetch("/_api/classes").then(r=>{if(!r.ok)throw new Error("Could not load classes");return r.json()}).then(d=>setClasses(d.classes??[])).catch(()=>setClasses([])).finally(()=>setClassesLoading(false))},[]);
  const kind=category==="Emergency"||category==="Weather"?"urgent":category==="Schedule Update"?"schedule":category==="Race Day"?"staging":"general";
  const submit=async(e:FormEvent)=>{e.preventDefault();setNotice("");if(!allRiders&&!officials&&!classIds.length){setNotice("Choose at least one audience before continuing.");return}if(sendMode==="later"&&(!scheduledFor||new Date(scheduledFor).getTime()<=Date.now())){setNotice("Choose a future date and time for a scheduled announcement.");return}if(!previewing){setPreviewing(true);return}setSending(true);try{
    const result=await postAnnouncement({title,message,kind,allRiders,officialsIncluded:officials,classIds,privateRecipientId:null,scheduledFor:sendMode==="later"&&scheduledFor?new Date(scheduledFor).toISOString():null});
    setNotice(result.announcement.status==="scheduled"?"Announcement scheduled.":"Announcement sent to rider devices.");onSent();
  }catch(error){setNotice(error instanceof Error?error.message:"Could not send announcement")}finally{setSending(false)}};
  const toggleClass=(id:string)=>{setAllRiders(false);setClassIds(v=>v.includes(id)?v.filter(x=>x!==id):[...v,id])};
  const useQuickAnnouncement=(preset:(typeof quickAnnouncements)[number])=>{setTitle(preset.title);setMessage(preset.message);setCategory(preset.category)};
  return <section className={styles.overlay}>
    <form className={styles.card} onSubmit={submit}>
      <header><div><strong>{previewing?"PREVIEW ANNOUNCEMENT":"NEW ANNOUNCEMENT"}</strong><span>{previewing?"Confirm before sending or scheduling":"Send live race-day information"}</span></div><button type="button" onClick={onClose} aria-label="Close"><X/></button></header>
      {previewing ? <>
        <section className={styles.previewCard}>
          <div className={styles.previewMeta}><b>{category.toUpperCase()}</b><span>{sendMode==="later"?"SCHEDULED":"SEND NOW"}</span></div>
          <h2>{title}</h2><p>{message}</p>
          <small>Audience: {allRiders?"All Riders":classIds.length?`${classIds.length} selected class${classIds.length===1?"":"es"}`:"Officials / Staff"}{officials&&allRiders?" + Officials / Staff":""}</small>
          {sendMode==="later"&&scheduledFor&&<small>Delivery: {new Date(scheduledFor).toLocaleString()}</small>}
        </section>
        <div className={styles.previewActions}><Button type="button" variant="outline" onClick={()=>setPreviewing(false)}><ArrowLeft/>BACK TO EDIT</Button><Button type="submit" size="lg" disabled={sending}><Send/>{sending?"SENDING…":sendMode==="later"?"CONFIRM SCHEDULE":"SEND ANNOUNCEMENT"}</Button></div>
      </> : <>
      <section className={styles.quickAnnouncements}>
        <strong>QUICK ANNOUNCEMENTS</strong>
        <small>Tap one to fill the announcement, then edit it if needed.</small>
        <div>{quickAnnouncements.map(preset=><button type="button" key={preset.key} onClick={()=>useQuickAnnouncement(preset)}>{preset.label}</button>)}</div>
      </section>
      <label>Headline<Input disabled={sending} value={title} maxLength={80} onChange={e=>setTitle(e.target.value)} required/></label>
      <label>Category<Select disabled={sending} value={category} onValueChange={value=>setCategory(value as Category)}><SelectTrigger><SelectValue/></SelectTrigger><SelectContent>{(["General","Schedule Update","Race Day","Emergency","Registration","Weather","Results / Awards"] as Category[]).map(value=><SelectItem key={value} value={value}>{value}</SelectItem>)}</SelectContent></Select></label>
      <label>Message<Textarea disabled={sending} value={message} maxLength={500} rows={4} onChange={e=>setMessage(e.target.value)} required/></label>
      <div className={styles.audience}>
        <strong>SEND TO</strong>
        <div><button type="button" className={allRiders?styles.selected:""} onClick={()=>{setAllRiders(true);setClassIds([])}}>ALL RIDERS</button><button type="button" className={officials?styles.selected:""} onClick={()=>setOfficials(v=>!v)}>+ OFFICIALS</button></div>
        <small>{classesLoading?"Loading racing classes…":"Or select racing classes:"}</small>
        <div className={styles.classes}>{classes.map(c=><button type="button" key={c.id} className={classIds.includes(c.id)?styles.selected:""} onClick={()=>toggleClass(c.id)}>{c.name}</button>)}</div>
      </div>
      <div className={styles.sendTiming}><strong>DELIVERY</strong><div><button type="button" className={sendMode==="now"?styles.selected:""} onClick={()=>setSendMode("now")}>SEND NOW</button><button type="button" className={sendMode==="later"?styles.selected:""} onClick={()=>setSendMode("later")}>SCHEDULE</button></div>{sendMode==="later"&&<label>Send date and time<Input type="datetime-local" value={scheduledFor} onChange={e=>setScheduledFor(e.target.value)} required/></label>}</div>
      {notice&&<p className={notice.startsWith("Announcement s")?styles.success:styles.error}>{notice}</p>}
      <Button type="submit" size="lg" disabled={sending||!title.trim()||!message.trim()||(!allRiders&&!officials&&!classIds.length)}><Eye/>NEXT: PREVIEW</Button>
      </>}
    </form>
  </section>
}