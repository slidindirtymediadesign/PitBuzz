import { useCallback, useEffect, useState } from "react";
import { Mail, RotateCcw, Volume2, VolumeX } from "lucide-react";
import { Button } from "./Button";
import { getAnnouncements, AnnouncementItem } from "../endpoints/announcements_GET.schema";
import { postAnnouncementRead } from "../endpoints/announcement-read_POST.schema";
import styles from "./LiveAnnouncement.module.css";
import { speakPitBuzzAnnouncement } from "../helpers/alertAudio";
import { useAuth } from "../helpers/useAuth";

export function LiveAnnouncement({admin=false,refreshKey=0}:{admin?:boolean;refreshKey?:number}){
 const [item,setItem]=useState<AnnouncementItem|null>(null);const [playing,setPlaying]=useState(false);const [loaded,setLoaded]=useState(false);
 const {authState}=useAuth();
 const [autoPlay,setAutoPlay]=useState(()=>typeof localStorage==="undefined"||localStorage.getItem("pitbuzz-autoplay")!=="0");
 const spokenKey=authState.type==="authenticated"?`pitbuzz-last-autoplay-${authState.user.id}`:null;
 const load=useCallback(()=>getAnnouncements().then(d=>{const newest=d.announcements[0]??null;setItem(newest);setLoaded(true);if(newest&&spokenKey&&localStorage.getItem(spokenKey)!==newest.id){localStorage.setItem(spokenKey,newest.id);if(autoPlay&&!newest.isRead&&newest.kind!=="private"){setPlaying(true);window.setTimeout(()=>speakPitBuzzAnnouncement(newest.message,()=>setPlaying(true),()=>setPlaying(false)),430)}}}).catch(()=>setLoaded(true)),[autoPlay,spokenKey]);
 useEffect(()=>{const refresh=()=>{if(document.visibilityState==="visible")void load()};void load();const timer=window.setInterval(refresh,30000);const syncAudio=()=>setAutoPlay(localStorage.getItem("pitbuzz-autoplay")!=="0");window.addEventListener("pitbuzz:announcement",load);window.addEventListener("pitbuzz:audio-settings",syncAudio);window.addEventListener("focus",refresh);document.addEventListener("visibilitychange",refresh);return()=>{window.clearInterval(timer);window.removeEventListener("pitbuzz:announcement",load);window.removeEventListener("pitbuzz:audio-settings",syncAudio);window.removeEventListener("focus",refresh);document.removeEventListener("visibilitychange",refresh)}},[load,refreshKey]);
 const play=()=>{if(!item)return;if(playing){window.speechSynthesis.cancel();setPlaying(false);return}speakPitBuzzAnnouncement(item.message,()=>setPlaying(true),()=>setPlaying(false))};
 const markRead=async()=>{if(!item)return;try{await postAnnouncementRead({announcementId:item.id});setItem(v=>v?({...v,isRead:true}):v)}catch{}};
 const toggleAutoPlay=()=>setAutoPlay(current=>{const next=!current;localStorage.setItem("pitbuzz-autoplay",next?"1":"0");window.dispatchEvent(new Event("pitbuzz:audio-settings"));if(next)speakPitBuzzAnnouncement("Auto-play on");else{window.speechSynthesis.cancel();setPlaying(false)}return next});
 if(!loaded)return <section className={styles.emptyCard}><strong>CHECKING FOR ANNOUNCEMENTS…</strong></section>;
 if(!item)return <section className={styles.emptyCard}><strong>NO ACTIVE ANNOUNCEMENTS</strong><span>New race-day messages will appear here.</span></section>;
 const sent=item.sentAt?new Date(item.sentAt).toLocaleTimeString([],{hour:"numeric",minute:"2-digit"}):"Scheduled";
 const playLabel=playing?"STOP AUDIO":item.isRead?"REPLAY AUDIO":"PLAY AUDIO";
 return <section className={admin?styles.adminCard:styles.card}>
   <div className={styles.top}><em>{admin?"● LIVE ANNOUNCEMENT":item.kind==="private"?"PRIVATE MESSAGE":item.kind.toUpperCase()}</em><time>{admin?"Started: ":"Today • "}{sent}</time></div>
   {!admin&&<b className={item.isRead?styles.readBadge:styles.newBadge}>{item.isRead?<i className={styles.readLight}/>:<Mail/>}{item.isRead?"READ":"NEW"}</b>}
   {admin&&<b className={styles.badge}>{item.kind==="urgent"?"CRITICAL":item.kind.toUpperCase()}</b>}
   <div className={styles.hero}><h1>{item.title}</h1><span>📣</span></div>
   <p>{item.message}</p><small>By: NATVA Official</small>
   {item.kind!=="private"&&<button className={styles.autoPlayToggle} onClick={toggleAutoPlay}>{autoPlay?<Volume2/>:<VolumeX/>} AUTO-PLAY {autoPlay?"ON":"OFF"}</button>}
   {!admin&&<><div className={styles.buttons}><Button onClick={play} size="lg">{playing?<VolumeX/>:item.isRead?<RotateCcw/>:<Volume2/>}{playLabel}</Button></div>{!item.isRead&&<button className={styles.markRead} onClick={markRead}>MARK AS READ</button>}</>}
 </section>
}