import { useEffect,useState } from "react";
import { CalendarDays,ChevronRight,Clock3,Flag,Trophy } from "lucide-react";
import { getScheduleItems,ScheduleItem } from "../endpoints/schedule-items_GET.schema";
import styles from "../pages/_index.module.css";

function ItemIcon({item}:{item:ScheduleItem}){
  if(item.raceNumber)return <Flag/>;
  if(/award|podium/i.test(item.title))return <Trophy/>;
  if(/meeting/i.test(item.title))return <Clock3/>;
  return <CalendarDays/>;
}

export function RaceDaySchedule({limit}:{limit?:number}){
  const [items,setItems]=useState<ScheduleItem[]|null>(null);
  useEffect(()=>{let active=true;const load=()=>getScheduleItems().then(d=>{if(active)setItems(d.items)}).catch(()=>{if(active)setItems([])});const refresh=()=>{if(document.visibilityState==="visible")void load()};void load();const timer=window.setInterval(refresh,30000);document.addEventListener("visibilitychange",refresh);window.addEventListener("focus",refresh);return()=>{active=false;window.clearInterval(timer);document.removeEventListener("visibilitychange",refresh);window.removeEventListener("focus",refresh)}},[]);
  const firstDate=items?.[0]?.eventDate?.slice(0,10);
  const raceDayItems=items?.filter(x=>x.eventDate.slice(0,10)===firstDate)??[];
  const visible=limit?raceDayItems.slice(0,limit):raceDayItems;
  if(items===null)return <section className={styles.scheduleEmpty}>Loading schedule…</section>;
  if(!visible?.length)return <section className={styles.scheduleEmpty}><strong>Nothing scheduled right now.</strong><span>Upcoming race-day calls will appear here.</span></section>;
  return <section className={styles.schedule}>
    {visible.map((item,index)=><article key={item.id}>
      <span className={index%2===0?styles.redIcon:styles.blueIcon}><ItemIcon item={item}/></span>
      <time className={index%2===0?styles.redTime:""}>{item.scheduledTime?new Date(`2000-01-01T${item.scheduledTime}`).toLocaleTimeString([], {hour:"numeric",minute:"2-digit"}):"TBA"}</time>
      <div><strong>{item.raceNumber?`Race ${item.raceNumber} — `:""}{item.title}</strong><small>{item.location||"Race-day schedule"}</small></div>
      <ChevronRight className={styles.rowArrow}/>
    </article>)}
  </section>;
}