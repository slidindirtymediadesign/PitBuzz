import { useEffect } from "react";
import { listenToPush } from "../helpers/pushClient";
import { playPitBuzzAlert } from "../helpers/alertAudio";

export function PushBootstrap() {
  useEffect(() => {
    const playAlert = (event: Event) => {
      const payload=(event as CustomEvent<{data?:Record<string,unknown>}>).detail;
      if(payload?.data?.kind!=="private") playPitBuzzAlert();
    };
    window.addEventListener("pitbuzz:announcement", playAlert);
    const firebaseMessaging = (globalThis as any).Capacitor?.Plugins?.FirebaseMessaging;
    if (firebaseMessaging?.createChannel) {
      void firebaseMessaging.createChannel({
        id: "fcm_fallback_notification_channel",
        name: "PitBuzz Announcements",
        importance: 5,
        visibility: 1,
      });
    }
    const stopPush = listenToPush();
    return () => {
      window.removeEventListener("pitbuzz:announcement", playAlert);
      stopPush();
    };
  }, []);
  return null;
}