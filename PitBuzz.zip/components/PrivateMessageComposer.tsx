import { FormEvent, useEffect, useState } from "react";
import { ArrowLeft, Eye, Send, UserRound, X } from "lucide-react";
import { Input } from "./Input";
import { Textarea } from "./Textarea";
import { Button } from "./Button";
import { getRiders, RiderResult } from "../endpoints/riders_GET.schema";
import { postAnnouncement } from "../endpoints/announcements_POST.schema";
import styles from "./AnnouncementComposer.module.css";

export function PrivateMessageComposer({onClose,onSent}:{onClose:()=>void;onSent:()=>void}){
 const [query,setQuery]=useState("");const [riders,setRiders]=useState<RiderResult[]>([]);const [selected,setSelected]=useState<RiderResult|null>(null);
 const [title,setTitle]=useState("Private Message");const [message,setMessage]=useState("");const [notice,setNotice]=useState("");const [sending,setSending]=useState(false);const [previewing,setPreviewing]=useState(false);const [searching,setSearching]=useState(false);
 useEffect(()=>{if(selected||query.trim().length<2){setRiders([]);setSearching(false);return}let active=true;setSearching(true);const timer=window.setTimeout(()=>getRiders(query).then(d=>{if(active)setRiders(d.riders)}).catch(()=>{if(active)setRiders([])}).finally(()=>{if(active)setSearching(false)}),250);return()=>{active=false;window.clearTimeout(timer)}},[query,selected]);
 const submit=async(e:FormEvent)=>{e.preventDefault();if(!selected){setNotice("Choose a rider first.");return}if(!previewing){setNotice("");setPreviewing(true);return}setSending(true);setNotice("");try{await postAnnouncement({title,message,kind:"private",allRiders:false,officialsIncluded:false,classIds:[],privateRecipientId:selected.managed?null:selected.id,privateTeamRiderId:selected.teamRiderId??null,scheduledFor:null});setNotice("Private message sent.");onSent()}catch(error){setNotice(error instanceof Error?error.message:"Could not send message")}finally{setSending(false)}};
 return <section className={styles.overlay}><form className={styles.card} onSubmit={submit}>
  <header><div><strong>{previewing?"PREVIEW PRIVATE MESSAGE":"PRIVATE MESSAGE"}</strong><span>Private — not played aloud automatically</span></div><button type="button" onClick={onClose} aria-label="Close"><X/></button></header>
  {previewing&&selected?<><section className={styles.previewCard}><div className={styles.previewMeta}><b>PRIVATE MESSAGE</b><span>{selected.managed?selected.teamName||"TEAM RIDER":"ONE RIDER"}</span></div><h2>{title}</h2><p>{message}</p><small>To: {selected.displayName}{selected.managed?" and linked Team followers":""}</small></section><div className={styles.previewActions}><Button type="button" variant="outline" onClick={()=>setPreviewing(false)}><ArrowLeft/>BACK TO EDIT</Button><Button type="submit" size="lg" disabled={sending}><Send/>{sending?"SENDING…":"SEND PRIVATE MESSAGE"}</Button></div></> : <>
  <label>Find rider by name, number or email<Input value={query} disabled={sending} onChange={e=>{setQuery(e.target.value);setSelected(null);setNotice("")}} placeholder="Start typing a rider’s name or number…"/></label>
  {searching&&<small>Searching riders…</small>}
  {!searching&&!selected&&query.trim().length>=2&&!riders.length&&<small>No matching riders found.</small>}
  <div className={styles.classes}>{riders.map(r=><button type="button" key={r.teamRiderId??r.id} className={(selected?.teamRiderId??selected?.id)===(r.teamRiderId??r.id)?styles.selected:""} onClick={()=>{setSelected(r);setQuery(r.displayName);setRiders([])}}><UserRound/> {r.displayName}{r.managed?` · ${r.teamName||"Team rider"}`:""}</button>)}</div>
  {selected&&<p className={styles.success}>{selected.managed?`Private to ${selected.displayName} — delivered to linked Team followers`:`Sending only to: ${selected.displayName}`}</p>}
  <label>Headline<Input value={title} disabled={sending} maxLength={80} onChange={e=>setTitle(e.target.value)} required/></label>
  <label>Message<Textarea value={message} disabled={sending} maxLength={500} rows={4} onChange={e=>setMessage(e.target.value)} required/></label>
  {notice&&<p className={notice==="Private message sent."?styles.success:styles.error}>{notice}</p>}
  <Button type="submit" size="lg" disabled={sending||!selected||!title.trim()||!message.trim()}><Eye/>NEXT: PREVIEW</Button></>}
 </form></section>
}