export type TeamRider={id:string;name:string;raceNumber:string|null;isManaged:boolean;classIds:string[]};
export type TeamMember={id:string;name:string;phone:string|null;role:"owner"|"admin"|"family"|"crew";followsAllRiders:boolean;riderIds:string[]};
export type TeamData={id:string;name:string;canManage:boolean;riders:TeamRider[];members:TeamMember[]};
export type OutputType={team:TeamData|null};
export async function getTeam():Promise<OutputType>{const r=await fetch("/_api/team",{credentials:"include"});if(!r.ok)throw new Error("Could not load team");return r.json()}