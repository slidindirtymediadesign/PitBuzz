import { z } from "zod";
export const schema=z.object({classIds:z.array(z.string()).max(20)});
export type OutputType={saved:true};
export async function postSubscriptions(body:z.infer<typeof schema>):Promise<OutputType>{const r=await fetch("/_api/subscriptions",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(schema.parse(body))});if(!r.ok)throw new Error("Could not save classes");return r.json()}