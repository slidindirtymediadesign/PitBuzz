import { db } from "../helpers/db";
import { getServerUserSession } from "../helpers/getServerUserSession";
import { schema } from "./schedule-items_POST.schema";

export async function handle(request:Request){
  try{
    const {user}=await getServerUserSession(request);
    if(!["super_admin","admin","announcer"].includes(user.role))return Response.json({error:"Admin access required"},{status:403});
    const input=schema.parse(await request.json());
    if(input.action==="delete"){
      await db.deleteFrom("scheduleItems").where("id","=",input.id).execute();
      return Response.json({saved:true});
    }
    if(input.action==="move"){
      const current=await db.selectFrom("scheduleItems").selectAll().where("id","=",input.id).executeTakeFirst();
      if(!current)return Response.json({error:"Schedule item not found"},{status:404});
      const rows=await db.selectFrom("scheduleItems").select(["id","sortOrder"]).where("eventDate","=",current.eventDate).orderBy("sortOrder","asc").orderBy("id","asc").execute();
      const index=rows.findIndex(x=>String(x.id)===String(current.id));
      const other=input.direction==="up"?rows[index-1]:rows[index+1];
      if(other)await db.transaction().execute(async trx=>{await trx.updateTable("scheduleItems").set({sortOrder:other.sortOrder}).where("id","=",current.id).execute();await trx.updateTable("scheduleItems").set({sortOrder:current.sortOrder}).where("id","=",other.id).execute()});
      return Response.json({saved:true});
    }
    const eventDate=new Date(`${input.eventDate}T12:00:00`);
    const values={title:input.title,eventDate,scheduledTime:input.scheduledTime||null,location:input.location||null,raceNumber:input.raceNumber,status:input.status,classId:input.classId||null,createdBy:user.id};
    if(input.id)await db.updateTable("scheduleItems").set(values).where("id","=",input.id).execute();
    else {const max=await db.selectFrom("scheduleItems").select(db.fn.max("sortOrder").as("max")).where("eventDate","=",eventDate).executeTakeFirst();await db.insertInto("scheduleItems").values({...values,sortOrder:Number(max?.max??0)+1}).execute()}
    return Response.json({saved:true});
  }catch(error){return Response.json({error:error instanceof Error?error.message:"Could not save schedule"},{status:400})}
}