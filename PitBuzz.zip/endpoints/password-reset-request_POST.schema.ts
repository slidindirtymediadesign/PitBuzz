import { z } from "zod";
export const schema=z.object({email:z.string().email()});
export type OutputType={submitted:true};
export async function requestPasswordReset(email:string):Promise<OutputType>{const r=await fetch("/_api/password-reset-request",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email})});const d=await r.json();if(!r.ok)throw new Error(d.error||"Could not submit request");return d}