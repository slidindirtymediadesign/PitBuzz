import { z } from "zod";

export const schema = z.discriminatedUnion("action", [
  z.object({ action: z.literal("save"), subscription: z.record(z.unknown()) }),
  z.object({ action: z.literal("delete"), identity: z.string().min(1) }),
]);

export type OutputType = { saved?: true; deleted?: true };