export type RiderResult={id:number;displayName:string;email:string;teamRiderId?:string;managed?:boolean;teamName?:string};
export type OutputType={riders:RiderResult[]};
export async function getRiders(query:string):Promise<OutputType>{const r=await fetch("/_api/riders?q="+encodeURIComponent(query));if(!r.ok)throw new Error("Could not search riders");return r.json()}