import { z } from "zod";
export const schema=z.object({
  title:z.string().trim().min(2).max(80),
  message:z.string().trim().min(2).max(500),
  kind:z.enum(["general","private","schedule","staging","urgent"]).default("general"),
  allRiders:z.boolean().default(true),
  officialsIncluded:z.boolean().default(false),
  classIds:z.array(z.string()).max(23).default([]),
  privateRecipientId:z.number().int().positive().nullable().default(null),
  privateTeamRiderId:z.string().nullable().optional(),
  scheduledFor:z.string().datetime().nullable().default(null)
});
export type OutputType={announcement:{id:string;status:"sent"|"scheduled"}};
export async function postAnnouncement(body:z.infer<typeof schema>):Promise<OutputType>{const r=await fetch("/_api/announcements",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(schema.parse(body))});const data=await r.json();if(!r.ok)throw new Error(data.error||"Could not send announcement");return data}