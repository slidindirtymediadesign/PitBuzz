import { z } from "zod";
export const schema=z.discriminatedUnion("action",[
  z.object({action:z.literal("save"),id:z.string().nullable().default(null),title:z.string().trim().min(2).max(100),eventDate:z.string().min(1),scheduledTime:z.string().nullable().default(null),location:z.string().trim().max(120).nullable().default(null),raceNumber:z.number().int().positive().nullable().default(null),status:z.enum(["active","hidden"]).default("active"),classId:z.string().nullable().default(null)}),
  z.object({action:z.literal("delete"),id:z.string()}),
  z.object({action:z.literal("move"),id:z.string(),direction:z.enum(["up","down"])})
]);
export type OutputType={saved:true};
export async function postScheduleItem(body:z.infer<typeof schema>):Promise<OutputType>{const r=await fetch("/_api/schedule-items",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(schema.parse(body))});const data=await r.json();if(!r.ok)throw new Error(data.error||"Could not save schedule");return data}