import { db } from "../helpers/db";
import { getServerUserSession } from "../helpers/getServerUserSession";
import { schema } from "./announcements_POST.schema";
import { sendPushNotifications } from "@floot/push";

async function sendAnnouncementPush(input: ReturnType<typeof schema.parse>, announcementId: string) {
  const recipientIds = new Set<number>();
  if (input.kind === "private" && input.privateRecipientId) {
    recipientIds.add(input.privateRecipientId);
  } else if(input.kind === "private" && input.privateTeamRiderId){
    const rider=await db.selectFrom("teamRiders").select("teamId").where("id","=",input.privateTeamRiderId).executeTakeFirst();
    if(rider){
      const allFollowers=await db.selectFrom("teamMembers").select("userId").where("teamId","=",rider.teamId).where("followsAllRiders","=",true).where("userId","is not",null).execute();
      allFollowers.forEach(m=>{if(m.userId)recipientIds.add(m.userId)});
      const selectedFollowers=await db.selectFrom("teamMemberRiders").innerJoin("teamMembers","teamMembers.id","teamMemberRiders.memberId").select("teamMembers.userId").where("teamMemberRiders.riderId","=",input.privateTeamRiderId).where("teamMembers.userId","is not",null).execute();
      selectedFollowers.forEach(m=>{if(m.userId)recipientIds.add(m.userId)});
    }
  } else {
    if (input.allRiders) {
      const riders = await db.selectFrom("users").select("id").where("role", "in", ["rider", "user"]).execute();
      riders.forEach((row) => recipientIds.add(row.id));
    }
    if (input.officialsIncluded) {
      const officials = await db.selectFrom("users").select("id").where("role", "in", ["super_admin", "admin", "announcer"]).execute();
      officials.forEach((row) => recipientIds.add(row.id));
    }
    if (input.classIds.length) {
      const subscribers = await db.selectFrom("riderClassSubscriptions")
        .select("userId").where("classId", "in", input.classIds).execute();
      subscribers.forEach((row) => recipientIds.add(row.userId));
      const teamRiders = await db.selectFrom("teamRiderClasses")
        .innerJoin("teamRiders","teamRiders.id","teamRiderClasses.riderId")
        .select(["teamRiderClasses.riderId","teamRiders.teamId"])
        .where("teamRiderClasses.classId","in",input.classIds).execute();
      for(const rider of teamRiders){
        const allFollowers=await db.selectFrom("teamMembers").select("userId")
          .where("teamId","=",rider.teamId).where("followsAllRiders","=",true).where("userId","is not",null).execute();
        allFollowers.forEach(m=>{if(m.userId)recipientIds.add(m.userId)});
        const selectedFollowers=await db.selectFrom("teamMemberRiders")
          .innerJoin("teamMembers","teamMembers.id","teamMemberRiders.memberId")
          .select("teamMembers.userId").where("teamMemberRiders.riderId","=",rider.riderId)
          .where("teamMembers.userId","is not",null).execute();
        selectedFollowers.forEach(m=>{if(m.userId)recipientIds.add(m.userId)});
      }
    }
  }
  if (!recipientIds.size) return;
  const stored = await db.selectFrom("pushSubscriptions")
    .select(["identity", "subscription"])
    .where("userId", "in", [...recipientIds])
    .execute();
  if (!stored.length) return;
  const subscriptions = stored.map((row) => row.subscription) as unknown as Parameters<typeof sendPushNotifications>[0];
  const results = await sendPushNotifications(
    subscriptions,
    {
      title: input.kind === "private" ? "Private PitBuzz Message" : input.title,
      body: input.message,
      url: "/",
      tag: `announcement-${announcementId}`,
      data: { announcementId, kind: input.kind },
      showWhenFocused: true,
    },
  );
  const gone = stored.filter((_, index) => results[index]?.gone).map((row) => row.identity);
  if (gone.length) await db.deleteFrom("pushSubscriptions").where("identity", "in", gone).execute();
}

export async function handle(request:Request){
  try{
    const {user}=await getServerUserSession(request);
    if(!["super_admin","admin","announcer"].includes(user.role))return Response.json({error:"Admin access required"},{status:403});
    const input=schema.parse(await request.json());
    if(input.kind==="private"&&!input.privateRecipientId&&!input.privateTeamRiderId)return Response.json({error:"Choose a rider"},{status:400});
    if(input.kind!=="private"&&!input.allRiders&&!input.officialsIncluded&&!input.classIds.length)return Response.json({error:"Choose at least one audience"},{status:400});
    const scheduled=input.scheduledFor?new Date(input.scheduledFor):null;
    const isScheduled=Boolean(scheduled&&scheduled.getTime()>Date.now());
    const now=new Date();
    const expiresAt=new Date((isScheduled?scheduled!:now).getTime()+60*60*1000);
    const inserted=await db.transaction().execute(async trx=>{
      const row=await trx.insertInto("announcements").values({
        title:input.title,message:input.message,kind:input.kind,createdBy:user.id,
        allRiders:input.kind==="private"?false:input.allRiders,officialsIncluded:input.kind==="private"?false:input.officialsIncluded,
        privateRecipientId:input.privateRecipientId,privateTeamRiderId:input.privateTeamRiderId??null,
        status:isScheduled?"scheduled":"sent",scheduledFor:isScheduled?scheduled:null,
        sentAt:isScheduled?null:now,expiresAt
      }).returning("id").executeTakeFirstOrThrow();
      if(input.classIds.length)await trx.insertInto("announcementClasses").values(input.classIds.map(classId=>({announcementId:row.id,classId}))).execute();
      return row;
    });
    if(!isScheduled){
      try{await sendAnnouncementPush(input,String(inserted.id))}
      catch(pushError){console.error("Push notification failed:",pushError)}
    }
    return Response.json({announcement:{id:String(inserted.id),status:isScheduled?"scheduled":"sent"}});
  }catch(error){return Response.json({error:error instanceof Error?error.message:"Could not send announcement"},{status:400})}
}