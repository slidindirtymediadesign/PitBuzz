import { db } from "../helpers/db";
import { getServerUserSession } from "../helpers/getServerUserSession";

export async function handle(request:Request){
  const now=new Date();
  await db.updateTable("announcements").set({status:"sent",sentAt:now})
    .where("status","=","scheduled").where("scheduledFor","<=",now).execute();
  await db.updateTable("announcements").set({status:"expired"}).where("status","=","sent").where("expiresAt","<=",now).execute();
  let user:Awaited<ReturnType<typeof getServerUserSession>>["user"]|null=null;
  try{user=(await getServerUserSession(request)).user}catch{user=null}
  let teamClassIds:string[]=[];
  let followedTeamRiderIds:string[]=[];
  if(user){
    const memberships=await db.selectFrom("teamMembers").select(["id","teamId","followsAllRiders"]).where("userId","=",user.id).execute();
    for(const member of memberships){
      let riderIds:string[]=[];
      if(member.followsAllRiders){
        const riders=await db.selectFrom("teamRiders").select("id").where("teamId","=",member.teamId).execute();
        riderIds=riders.map(r=>String(r.id));
      }else{
        const followed=await db.selectFrom("teamMemberRiders").select("riderId").where("memberId","=",member.id).execute();
        riderIds=followed.map(r=>String(r.riderId));
      }
      if(riderIds.length){
        followedTeamRiderIds.push(...riderIds);
        const classes=await db.selectFrom("teamRiderClasses").select("classId").where("riderId","in",riderIds).execute();
        teamClassIds.push(...classes.map(c=>String(c.classId)));
      }
    }
    teamClassIds=[...new Set(teamClassIds)];
    followedTeamRiderIds=[...new Set(followedTeamRiderIds)];
  }
  let query=db.selectFrom("announcements")
    .leftJoin("announcementClasses","announcementClasses.announcementId","announcements.id")
    .leftJoin("riderClassSubscriptions",join=>join
      .onRef("riderClassSubscriptions.classId","=","announcementClasses.classId")
      .on("riderClassSubscriptions.userId","=",user?.id??-1))
    .select(["announcements.id as id","announcements.title as title","announcements.message as message","announcements.kind as kind","announcements.sentAt as sentAt","announcements.expiresAt as expiresAt","announcements.allRiders as allRiders","announcements.officialsIncluded as officialsIncluded"])
    .distinct().where("status","=","sent")
    .where(eb=>eb.or([eb("expiresAt","is",null),eb("expiresAt",">",now)]))
  if(user){
    const staff=["super_admin","admin","announcer"].includes(user.role);
    query=query.where(eb=>eb.or([
      eb("allRiders","=",true),
      eb("privateRecipientId","=",user!.id),
      ...(followedTeamRiderIds.length?[eb("privateTeamRiderId","in",followedTeamRiderIds)]:[]),
      eb("riderClassSubscriptions.userId","=",user!.id),
      ...(teamClassIds.length?[eb("announcementClasses.classId","in",teamClassIds)]:[]),
      ...(staff?[eb("officialsIncluded","=",true)]:[])
    ]));
  }else query=query.where("allRiders","=",true);
  const rows=await query.orderBy("sentAt","desc").limit(20).execute();
  const readIds=user&&rows.length?await db.selectFrom("announcementReads").select("announcementId").where("userId","=",user.id).where("announcementId","in",rows.map(row=>row.id)).execute():[];
  const readSet=new Set(readIds.map(row=>String(row.announcementId)));
  return Response.json({announcements:rows.map(row=>({...row,id:String(row.id),sentAt:row.sentAt?.toISOString()??null,expiresAt:row.expiresAt?.toISOString()??null,isRead:readSet.has(String(row.id))}))});
}