import { db } from "../helpers/db";
import { getServerUserSession } from "../helpers/getServerUserSession";
import { schema } from "./push-subscriptions_POST.schema";
import type { JsonObject } from "../helpers/schema";

function getIdentity(subscription: Record<string, unknown>): string | null {
  if (typeof subscription.endpoint === "string") return subscription.endpoint;
  if (typeof subscription.fcmToken === "string") return subscription.fcmToken;
  if (typeof subscription.apnsToken === "string") return subscription.apnsToken;
  return null;
}

export async function handle(request: Request) {
  try {
    const { user } = await getServerUserSession(request);
    const input = schema.parse(await request.json());
    if (input.action === "delete") {
      await db.deleteFrom("pushSubscriptions")
        .where("userId", "=", user.id)
        .where("identity", "=", input.identity)
        .execute();
      return Response.json({ deleted: true });
    }
    const identity = getIdentity(input.subscription);
    if (!identity) return Response.json({ error: "Invalid notification subscription" }, { status: 400 });
    await db.insertInto("pushSubscriptions")
      .values({ userId: user.id, identity, subscription: input.subscription as JsonObject })
      .onConflict((conflict) => conflict.column("identity").doUpdateSet({
        userId: user.id,
        subscription: input.subscription as JsonObject,
        updatedAt: new Date(),
      }))
      .execute();
    return Response.json({ saved: true });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "Could not update notifications" },
      { status: 400 },
    );
  }
}