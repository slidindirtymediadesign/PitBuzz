import { z } from "zod";
export const schema = z.object({});
export type OutputType = { classes: Array<{id:string;name:string;sortOrder:number}> };
export async function getClasses():Promise<OutputType>{const r=await fetch("/_api/classes");if(!r.ok)throw new Error("Could not load classes");return r.json()}