import { db } from "../helpers/db";
import { getServerUserSession } from "../helpers/getServerUserSession";

export async function handle(request:Request){
  const url=new URL(request.url);
  let user:Awaited<ReturnType<typeof getServerUserSession>>["user"]|null=null;
  try{user=(await getServerUserSession(request)).user}catch{user=null}
  const staff=Boolean(user&&["super_admin","admin","announcer"].includes(user.role));
  const admin=url.searchParams.get("admin")==="1"&&staff;
  let query=db.selectFrom("scheduleItems").selectAll();
  if(!admin){
    query=query.where("status","=","active");
    if(user&&!["super_admin","admin","announcer"].includes(user.role)){
      const subscriptions=await db.selectFrom("riderClassSubscriptions").select("classId").where("userId","=",user.id).execute();
      const memberships=await db.selectFrom("teamMembers").select(["id","teamId","followsAllRiders"]).where("userId","=",user.id).execute();
      const teamIds:string[]=[];
      for(const member of memberships){
        const riders=member.followsAllRiders
          ?await db.selectFrom("teamRiders").select("id").where("teamId","=",member.teamId).execute()
          :await db.selectFrom("teamMemberRiders").select("riderId as id").where("memberId","=",member.id).execute();
        if(riders.length){const classes=await db.selectFrom("teamRiderClasses").select("classId").where("riderId","in",riders.map(r=>r.id)).execute();teamIds.push(...classes.map(c=>String(c.classId)))}
      }
      const ids=[...new Set([...subscriptions.map(x=>String(x.classId)),...teamIds])];
      query=query.where(eb=>ids.length?eb.or([eb("classId","is",null),eb("classId","in",ids)]):eb("classId","is",null));
    }else if(!user)query=query.where("classId","is",null);
  }
  const rows=await query.orderBy("eventDate","asc").orderBy("sortOrder","asc").orderBy("id","asc").limit(100).execute();
  return Response.json({items:rows.map(row=>({id:String(row.id),title:row.title,eventDate:row.eventDate.toISOString(),scheduledTime:row.scheduledTime,location:row.location,raceNumber:row.raceNumber,status:row.status,sortOrder:row.sortOrder,classId:row.classId===null?null:String(row.classId)}))});
}