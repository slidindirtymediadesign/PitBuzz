import { z } from "zod";
export const schema=z.object({userId:z.number().int().positive(),newPassword:z.string().min(8),requestId:z.string().nullable().default(null)});
export type OutputType={reset:true};
export async function adminResetPassword(body:z.infer<typeof schema>):Promise<OutputType>{const r=await fetch("/_api/admin-password-reset",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(schema.parse(body))});const d=await r.json();if(!r.ok)throw new Error(d.error||"Could not reset password");return d}