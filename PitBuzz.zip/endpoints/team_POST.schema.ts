import { z } from "zod";
export const schema=z.discriminatedUnion("action",[
 z.object({action:z.literal("create_team"),name:z.string().min(1)}),
 z.object({action:z.literal("rename_team"),name:z.string().min(1)}),
 z.object({action:z.literal("add_rider"),name:z.string().min(1),raceNumber:z.string().optional()}),
 z.object({action:z.literal("remove_rider"),riderId:z.string()}),
 z.object({action:z.literal("set_rider_classes"),riderId:z.string(),classIds:z.array(z.string())}),
 z.object({action:z.literal("add_member"),name:z.string().min(1),phone:z.string().optional(),role:z.enum(["admin","family","crew"])}),
 z.object({action:z.literal("remove_member"),memberId:z.string()}),
 z.object({action:z.literal("set_member_riders"),memberId:z.string(),followsAllRiders:z.boolean(),riderIds:z.array(z.string())}),
 z.object({action:z.literal("update_member"),memberId:z.string(),name:z.string().min(1),phone:z.string().optional(),role:z.enum(["admin","family","crew"])})
]);
export type TeamAction=z.infer<typeof schema>;
export async function postTeam(body:TeamAction){const r=await fetch("/_api/team",{method:"POST",credentials:"include",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});const data=await r.json();if(!r.ok)throw new Error(data.error||"Team update failed");return data}