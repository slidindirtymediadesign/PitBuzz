import { z } from "zod";
export const schema=z.object({announcementId:z.string().min(1)});
export type OutputType={read:true};
export async function postAnnouncementRead(body:z.infer<typeof schema>):Promise<OutputType>{const r=await fetch("/_api/announcement-read",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(schema.parse(body))});if(!r.ok)throw new Error("Could not mark announcement as read");return r.json()}