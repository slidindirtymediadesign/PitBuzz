export type AdminUser={id:number;displayName:string;email:string;role:string;resetRequestId:string|null;resetRequestedAt:string|null};
export type OutputType={users:AdminUser[]};
export async function getAdminUsers():Promise<OutputType>{const r=await fetch("/_api/admin-users");const d=await r.json();if(!r.ok)throw new Error(d.error||"Could not load users");return d}