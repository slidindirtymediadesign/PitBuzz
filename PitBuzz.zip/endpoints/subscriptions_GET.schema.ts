import { z } from "zod";
export const schema=z.object({});
export type OutputType={classIds:string[]};
export async function getSubscriptions():Promise<OutputType>{const r=await fetch("/_api/subscriptions");if(!r.ok)throw new Error("Could not load subscriptions");return r.json()}