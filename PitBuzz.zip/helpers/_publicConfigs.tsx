// NOTE: this file is generated and should not be manually modified
export const VAPID_PUBLIC_KEY = "BFewO8OxN6KA1DoH1kjYzmiDEqAwH_hJI4G1Be-io4AvEG9XNXqVpkMmgZZj7xcFH3So58TH8ikd03zlADcZArg";