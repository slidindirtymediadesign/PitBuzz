import { VAPID_PUBLIC_KEY } from "./_publicConfigs";
import { toast } from "sonner";

export const SHOW_NOTIFICATIONS_WHILE_APP_OPEN = true;

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const raw = atob(base64);
  return Uint8Array.from([...raw].map((c) => c.charCodeAt(0)));
}

type NativePushSubscription = { fcmToken: string; platform: string };

type CapacitorFirebaseMessaging = {
  requestPermissions: () => Promise<{ receive: string }>;
  getToken: () => Promise<{ token: string }>;
  deleteToken?: () => Promise<void>;
  addListener: (
    event: string,
    cb: (data: {
      token?: string;
      actionId?: string;
      notification?: { data?: Record<string, unknown> };
    }) => void,
  ) => unknown;
};

function isNativeApp(): boolean {
  const cap = (globalThis as unknown as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor;
  return !!cap?.isNativePlatform?.();
}

function routeInApp(url: string): void {
  if (typeof window === "undefined") return;
  try {
    const target = new URL(url, window.location.origin);
    if (target.origin === window.location.origin) {
      const next = `${target.pathname}${target.search}${target.hash}`;
      if (`${window.location.pathname}${window.location.search}${window.location.hash}` === next) return;
      window.history.pushState({}, "", next);
      window.dispatchEvent(new PopStateEvent("popstate"));
      return;
    }
  } catch {
    // Fall through to normal browser navigation for malformed/external targets.
  }
  window.location.assign(url);
}

function getFirebaseMessaging(): CapacitorFirebaseMessaging | null {
  const cap = (globalThis as unknown as {
    Capacitor?: {
      isNativePlatform?: () => boolean;
      Plugins?: { FirebaseMessaging?: CapacitorFirebaseMessaging };
    };
  }).Capacitor;
  if (!cap || !cap.isNativePlatform || !cap.isNativePlatform()) return null;
  return (cap.Plugins && cap.Plugins.FirebaseMessaging) || null;
}

function getNativePlatform(): string {
  const cap = (globalThis as unknown as {
    Capacitor?: { getPlatform?: () => string };
  }).Capacitor;
  return cap && cap.getPlatform ? cap.getPlatform() : "unknown";
}

function subscribeNative(
  fm: CapacitorFirebaseMessaging,
): Promise<NativePushSubscription | null> {
  return new Promise((resolve) => {
    let settled = false;
    const finish = (value: NativePushSubscription | null) => {
      if (settled) return;
      settled = true;
      resolve(value);
    };
    const finishToken = (token: string | undefined) => {
      if (token) finish({ fcmToken: token, platform: getNativePlatform() });
    };
    fm.addListener("tokenReceived", (data) => finishToken(data && data.token));
    const tryGetToken = (attempt: number) => {
      fm.getToken()
        .then((result) => finishToken(result && result.token))
        .catch(() => {
          if (attempt < 5 && !settled) {
            setTimeout(() => tryGetToken(attempt + 1), 2000);
          }
        });
    };
    fm.requestPermissions()
      .then((permission) => {
        if (permission.receive !== "granted") {
          finish(null);
          return;
        }
        tryGetToken(0);
      })
      .catch(() => finish(null));
    setTimeout(() => finish(null), 20000);
  });
}

export async function subscribeToPush(): Promise<
  PushSubscriptionJSON | NativePushSubscription | null
> {
  const firebaseMessaging = getFirebaseMessaging();
  if (firebaseMessaging) {
    return subscribeNative(firebaseMessaging);
  }
  if (!("serviceWorker" in navigator) || !("PushManager" in window)) return null;
  const registration = await navigator.serviceWorker.register("/floot-push-sw.js", {
    scope: "/floot-push-sdk/",
  });
  if ((await Notification.requestPermission()) !== "granted") return null;
  const applicationServerKey = urlBase64ToUint8Array(VAPID_PUBLIC_KEY);
  let subscription = await registration.pushManager.getSubscription();
  if (subscription) {
    const existingKey = subscription.options?.applicationServerKey;
    const sameKey =
      !!existingKey &&
      new Uint8Array(existingKey).toString() === applicationServerKey.toString();
    if (!sameKey) {
      await subscription.unsubscribe();
      subscription = null;
    }
  }
  if (!subscription) {
    subscription = await registration.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey,
    });
  }
  return subscription.toJSON();
}

const pushStateHandlers = new Set<(enabled: boolean) => void>();

function emitPushState(enabled: boolean): void {
  pushStateHandlers.forEach((handler) => handler(enabled));
}

export function onPushEnabledChange(
  handler: (enabled: boolean) => void,
): () => void {
  pushStateHandlers.add(handler);
  return () => {
    pushStateHandlers.delete(handler);
  };
}

const PUSH_OPT_IN_KEY = "floot-push-opt-in";
const PUSH_IDENTITY_KEY = "floot-push-identity";

function readPushLocal(key: string): string | null {
  try {
    return typeof localStorage === "undefined" ? null : localStorage.getItem(key);
  } catch {
    return null;
  }
}

function writePushLocal(key: string, value: string | null): void {
  try {
    if (typeof localStorage === "undefined") return;
    if (value === null) localStorage.removeItem(key);
    else localStorage.setItem(key, value);
  } catch {
    return;
  }
}

function subscriptionIdentity(
  sub: PushSubscriptionJSON | NativePushSubscription,
): string | null {
  return (
    (sub as PushSubscriptionJSON).endpoint ||
    (sub as NativePushSubscription).fcmToken ||
    null
  );
}

function isPushOptedIn(): boolean {
  return readPushLocal(PUSH_OPT_IN_KEY) === "1";
}

export async function enablePush(): Promise<void> {
  const subscription = await subscribeToPush();
  if (!subscription) return;

  const identity = subscriptionIdentity(subscription);
  const previousIdentity = readPushLocal(PUSH_IDENTITY_KEY);
  if (previousIdentity && previousIdentity !== identity) {
    // The subscription rotated — DELETE the OLD one (previousIdentity) from your
    // server so pushes stop failing against the dead endpoint.
    await fetch("/_api/push-subscriptions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "delete", identity: previousIdentity }),
    });
  }

  // Save the new subscription to your server, keyed by its identity.
  const response = await fetch("/_api/push-subscriptions", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action: "save", subscription }),
  });
  if (!response.ok) throw new Error("Could not enable notifications");

  writePushLocal(PUSH_IDENTITY_KEY, identity);
  writePushLocal(PUSH_OPT_IN_KEY, "1");
  emitPushState(true);
}

export async function unsubscribeFromPush(): Promise<boolean> {
  const firebaseMessaging = getFirebaseMessaging();
  if (firebaseMessaging) {
    if (firebaseMessaging.deleteToken) {
      await firebaseMessaging.deleteToken().catch(() => {});
    }
    return true;
  }
  const registration = await navigator.serviceWorker.getRegistration("/floot-push-sdk/");
  const subscription = await registration?.pushManager.getSubscription();
  if (!subscription) return false;
  return subscription.unsubscribe();
}

export async function disablePush(): Promise<void> {
  await unsubscribeFromPush();

  // Delete your stored subscription(s) from your server.
  const identity = readPushLocal(PUSH_IDENTITY_KEY);
  if (identity) {
    const response = await fetch("/_api/push-subscriptions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "delete", identity }),
    });
    if (!response.ok) throw new Error("Could not disable notifications");
  }

  writePushLocal(PUSH_OPT_IN_KEY, null);
  writePushLocal(PUSH_IDENTITY_KEY, null);
  emitPushState(false);
}

export type PushMessagePayload = {
  title?: string;
  body?: string;
  url?: string;
  icon?: string;
  tag?: string;
  data?: Record<string, unknown>;
  showWhenFocused?: boolean;
  badgeCount?: number;
  actions?: { action: string; title: string; icon?: string; url?: string }[];
};

// Fires whenever a push arrives while at least one app window is open. Use it to
// present the notification in-app (toast, badge, live refresh) instead of / on
// top of the OS banner. `showWhenFocused: false` on the sent payload asks the
// service worker to skip the OS banner while the app is focused — BEST-EFFORT
// ONLY: current Apple OSes (iOS/macOS 18.4+) can render the banner at the
// system level without running the service worker, so there the flag cannot
// suppress it and this handler may not fire for that push. The reliable
// "don't alert me for what I'm already reading" behavior is to not SEND the
// push to actively-reading recipients (server-side presence + deferred
// read re-check — see the push skill).
// Returns a cleanup function that removes the listener.
export function onPushMessage(
  handler: (payload: PushMessagePayload) => void,
): () => void {
  const firebaseMessaging = getFirebaseMessaging();
  if (firebaseMessaging) {
    const listener = firebaseMessaging.addListener("notificationReceived", (event) => {
      const notification = (event as unknown as { notification?: { title?: string; body?: string; data?: Record<string, unknown> } }).notification;
      const data = notification?.data ?? {};
      let payloadData: Record<string, unknown> = {};
      if (typeof data.floot === "string") {
        try { payloadData = JSON.parse(data.floot) as Record<string, unknown>; } catch { payloadData = {}; }
      }
      handler({
        title: notification?.title,
        body: notification?.body,
        url: typeof data.url === "string" ? data.url : undefined,
        data: payloadData,
      });
    }) as { remove?: () => void } | undefined;
    return () => listener?.remove?.();
  }
  if (!("serviceWorker" in navigator)) return () => {};
  const listener = (event: MessageEvent) => {
    const data = event.data;
    if (data && data.type === "floot-push") {
      handler((data.payload ?? {}) as PushMessagePayload);
    }
  };
  navigator.serviceWorker.addEventListener("message", listener);
  return () => navigator.serviceWorker.removeEventListener("message", listener);
}

export type NotificationClickEvent = {
  // The clicked action button's id, or "" when the notification body was clicked.
  action: string;
  // The resolved target url (action url, or the payload's url), or null if none.
  url: string | null;
  // The payload's `data` object.
  data: Record<string, unknown>;
};

// Notification-click delivery (managed by Floot — do not edit). A tap can arrive
// when no page is alive: on mobile the "closed" PWA is killed, and the relaunch
// starts at start_url, not the notification url. The service worker persists
// every click to IndexedDB; the page drains it here on load / resume and routes
// it through the same handlers, so clicks survive a cold start.
const PENDING_CLICK_DB = "floot-push";
const PENDING_CLICK_STORE = "clicks";
const PENDING_CLICK_TTL_MS = 2 * 60 * 1000;

type PendingClick = {
  id: string;
  ts: number;
  action: string;
  url: string | null;
  data: Record<string, unknown>;
};

function openPushDb(): Promise<IDBDatabase | null> {
  return new Promise((resolve) => {
    try {
      if (typeof indexedDB === "undefined") return resolve(null);
      const req = indexedDB.open(PENDING_CLICK_DB, 1);
      req.onupgradeneeded = () => {
        try {
          req.result.createObjectStore(PENDING_CLICK_STORE, { keyPath: "id" });
        } catch {
          /* store may already exist */
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

// Read AND clear all pending clicks in one transaction, so a click is delivered
// exactly once even if several triggers (SW poke, visibilitychange, pageshow) or
// tabs race to drain it — IndexedDB serializes readwrite transactions per store.
function drainPendingClicks(): Promise<PendingClick[]> {
  return openPushDb().then((db) => {
    if (!db) return [];
    return new Promise<PendingClick[]>((resolve) => {
      let out: PendingClick[] = [];
      try {
        const tx = db.transaction(PENDING_CLICK_STORE, "readwrite");
        const store = tx.objectStore(PENDING_CLICK_STORE);
        const getAll = store.getAll();
        getAll.onsuccess = () => {
          out = (getAll.result as PendingClick[]) || [];
          store.clear();
        };
        tx.oncomplete = () => resolve(out);
        tx.onerror = () => resolve([]);
        tx.onabort = () => resolve([]);
      } catch {
        resolve([]);
      }
    });
  });
}

const clickHandlers = new Set<(event: NotificationClickEvent) => void>();

// Native (FCM) tap delivery: the plugin retains the launching tap until a
// listener consumes it, so an in-memory queue is enough for cold starts.
const pendingNativeClicks: NotificationClickEvent[] = [];

function handleNativeNotificationClick(event: {
  actionId?: string;
  notification?: { data?: Record<string, unknown> };
}): void {
  const data = event.notification?.data ?? {};
  let payloadData: Record<string, unknown> = {};
  if (typeof data.floot === "string") {
    try {
      payloadData = JSON.parse(data.floot) as Record<string, unknown>;
    } catch {
      payloadData = {};
    }
  }
  const click: NotificationClickEvent = {
    action: !event.actionId || event.actionId === "tap" ? "" : event.actionId,
    url: typeof data.url === "string" ? data.url : null,
    data: payloadData,
  };
  if (clickHandlers.size > 0) {
    dispatchClick(click);
  } else {
    pendingNativeClicks.push(click);
  }
  if (click.url) routeInApp(click.url);
}

function dispatchClick(event: NotificationClickEvent): void {
  clickHandlers.forEach((handler) => {
    try {
      handler(event);
    } catch {
      /* one throwing handler must not drop the others */
    }
  });
}

async function consumePendingClicks(): Promise<void> {
  // Nothing registered yet (e.g. this fired at cold start before the app mounted
  // its handler) — leave the clicks in the store; registering a handler drains them.
  if (clickHandlers.size === 0) return;
  const now = Date.now();
  const entries = await drainPendingClicks();
  for (const entry of entries) {
    // Skip stale clicks so a resume long after the tap doesn't yank the user around.
    if (typeof entry.ts === "number" && now - entry.ts > PENDING_CLICK_TTL_MS) {
      continue;
    }
    dispatchClick({
      action: entry.action || "",
      url: entry.url ?? null,
      data: (entry.data ?? {}) as Record<string, unknown>,
    });
  }
}

let clickConsumptionReady = false;
function setupClickConsumption(): void {
  if (clickConsumptionReady) return;
  clickConsumptionReady = true;
  const firebaseMessaging = getFirebaseMessaging();
  if (firebaseMessaging) {
    firebaseMessaging.addListener(
      "notificationActionPerformed",
      handleNativeNotificationClick,
    );
  }
  if (typeof navigator !== "undefined" && "serviceWorker" in navigator) {
    navigator.serviceWorker.addEventListener("message", (event: MessageEvent) => {
      const data = event.data;
      if (!data || data.type !== "floot-notificationclick") return;
      // A poke from the current SW carries an id and has already persisted the
      // click to IndexedDB — drain from there so the id keeps delivery exact.
      // A poke from an OLDER SW (pre-persistence) has no id and wrote nothing to
      // IndexedDB, so route its inline payload directly as a fallback.
      if (typeof data.id === "string") {
        void consumePendingClicks();
      } else {
        dispatchClick({
          action: data.action ?? "",
          url: data.url ?? null,
          data: (data.data ?? {}) as Record<string, unknown>,
        });
      }
    });
  }
  if (typeof document !== "undefined") {
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") void consumePendingClicks();
    });
  }
  if (typeof window !== "undefined") {
    window.addEventListener("pageshow", () => void consumePendingClicks());
  }
}

// Fires when the user clicks the notification (or an action button). Works
// whether the app was already open (delivered live) or was closed and relaunched
// by the tap (the click is replayed from IndexedDB once your handler is
// registered), so routing survives a cold start. Route in-app here (e.g.
// router.push); if you route here, omit url on the sent payload so the service
// worker doesn't also navigate. Returns a cleanup function.
export function onNotificationClick(
  handler: (event: NotificationClickEvent) => void,
): () => void {
  setupClickConsumption();
  clickHandlers.add(handler);
  // Drain anything the SW persisted before this handler existed (cold start).
  void consumePendingClicks();
  while (pendingNativeClicks.length > 0) {
    const pending = pendingNativeClicks.shift();
    if (pending) {
      dispatchClick(pending);
    }
  }
  return () => {
    clickHandlers.delete(handler);
  };
}

export function listenToPush(): () => void {
  // 1. A push arrived while the app is open.
  const offMessage = onPushMessage((payload) => {
    toast(payload.title || "New PitBuzz announcement", {
      description: payload.body,
    });
    window.dispatchEvent(new CustomEvent("pitbuzz:announcement", { detail: payload }));
  });

  // 2. The user clicked a notification while the app is open.
  const offClick = onNotificationClick((event) => {
    if (event.url) routeInApp(event.url);
  });

  return () => {
    offMessage();
    offClick();
  };
}

async function resyncPush(): Promise<void> {
  if (!isPushOptedIn()) return;
  if (!isNativeApp() && typeof Notification !== "undefined" && Notification.permission !== "granted") {
    return;
  }
  await enablePush();
}

(
  globalThis as unknown as {
    onPushSubscriptionChange?: (
      handler: (subscribed: boolean) => void,
    ) => () => void;
  }
).onPushSubscriptionChange?.((subscribed) => {
  if (!subscribed) void disablePush();
});

let pushResyncTimer: ReturnType<typeof setTimeout> | undefined;
if (typeof document !== "undefined") {
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState !== "visible") return;
    clearTimeout(pushResyncTimer);
    pushResyncTimer = setTimeout(() => void resyncPush(), 2000);
  });
}

void resyncPush();
