export function playPitBuzzAlert(): boolean {
  if (typeof window === "undefined") return false;
  const AudioContextClass = window.AudioContext ||
    (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AudioContextClass) return false;
  try {
    const context = new AudioContextClass();
    const start = context.currentTime;
    const notes = [
      { frequency: 784, delay: 0, duration: 0.13 },
      { frequency: 1047, delay: 0.17, duration: 0.22 },
    ];
    for (const note of notes) {
      const oscillator = context.createOscillator();
      const gain = context.createGain();
      oscillator.type = "square";
      oscillator.frequency.setValueAtTime(note.frequency, start + note.delay);
      gain.gain.setValueAtTime(0.0001, start + note.delay);
      gain.gain.exponentialRampToValueAtTime(0.16, start + note.delay + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + note.delay + note.duration);
      oscillator.connect(gain);
      gain.connect(context.destination);
      oscillator.start(start + note.delay);
      oscillator.stop(start + note.delay + note.duration);
    }
    window.setTimeout(() => void context.close(), 700);
    return true;
  } catch {
    return false;
  }
}

export function speakPitBuzzAnnouncement(
  message: string,
  onStart?: () => void,
  onEnd?: () => void,
): boolean {
  if (typeof window === "undefined" || !("speechSynthesis" in window) || !message.trim()) {
    return false;
  }
  try {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(message.trim());
    utterance.lang = "en-US";
    utterance.rate = 0.93;
    utterance.pitch = 1.05;
    utterance.onstart = () => onStart?.();
    utterance.onend = () => onEnd?.();
    utterance.onerror = () => onEnd?.();
    const voices = window.speechSynthesis.getVoices();
    utterance.voice = voices.find((voice) =>
      /samantha|ava|victoria|zira|susan|karen|google us english/i.test(voice.name),
    ) || voices.find((voice) => voice.lang.startsWith("en-US")) || null;
    window.speechSynthesis.speak(utterance);
    return true;
  } catch {
    return false;
  }
}